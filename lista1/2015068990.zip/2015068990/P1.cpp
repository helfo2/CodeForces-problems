#include <iostream>
#include <cmath>
#include <vector>
#include <map>
#include <set>

using namespace std;

int main(void) {
	int x, y; cin >> x >> y;

	cout << "X = " << x+y << endl;

	return 0;
}